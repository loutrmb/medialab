let stars = [];
let ufos = [];
let shapes = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(20, 0, 50);

  for (let i = 0; i < 100; i++) {
    stars.push(new Star());
  }

  for (let i = 0; i < 3; i++) {
    ufos.push(new UFO());
  }

  for (let i = 0; i < 10; i++) {
    shapes.push(new Shape());
  }
}

function draw() {
  background(255, 100, 0, 20);

  for (let i = 0; i < stars.length; i++) {
    stars[i].update();
    stars[i].show();
  }

  for (let i = 0; i < ufos.length; i++) {
    ufos[i].update();
    ufos[i].show();
  }

  for (let i = 0; i < shapes.length; i++) {
    shapes[i].update();
    shapes[i].show();
  }
}

class Star {
  constructor() {
    this.x = random(width);
    this.y = random(height);
    this.size = random(1, 4);
    this.speed = random(1, 3);
  }

  update() {
    this.x -= this.speed;

    if (this.x < 0) {
      this.x = width;
      this.y = random(height);
    }
  }

  show() {
    noStroke();
    fill(255);
    ellipse(this.x, this.y, this.size);
  }
}

class UFO {
  constructor() {
    this.x = random(width);
    this.y = random(height / 2);
    this.size = 30;
    this.speed = random(2, 5);
  }

  update() {
    this.x += this.speed;

    if (this.x > width) {
      this.x = 0;
      this.y = random(height / 2);
    }
  }

  show() {
    noStroke();
    fill(200, 200, 0);
    ellipse(this.x, this.y, this.size, this.size / 2);
    fill(255);
    ellipse(this.x - this.size / 4, this.y, this.size / 2);
  }
}

class Shape {
  constructor() {
    this.x = random(width);
    this.y = random(height / 2, height);
    this.size = random(20, 40);
    this.speed = random(1, 3);
    this.color1 = color(255, 150, 0, 150);
    this.color2 = color(255, 255, 0, 150);
  }

  update() {
    this.y -= this.speed;
    this.size += 1;

    if (this.y < 0) {
      this.y = random(height / 2, height);
      this.size = random(20, 40);
    }
  }

  show() {
    noStroke();
    let noiseVal = noise(this.x / 100, this.y / 100);
    let colorBetween = lerpColor(this.color1, this.color2, noiseVal);
    fill(colorBetween);
    ellipse(this.x + noiseVal * 20, this.y + noiseVal * 20, this.size + noiseVal * 10);
  }
}
